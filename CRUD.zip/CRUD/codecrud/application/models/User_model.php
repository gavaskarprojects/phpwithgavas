<?php 
class User_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

	public function insert( $data)
	{
		$result = $this->db->insert('users', $data);
		return $result;
	}

	public function update( $data, $id)
	{
		$result = $this->db->where('id', $id)->update('users', $data);
		return $result;
	}

	public function delete( $id)
	{
		$result = $this->db->delete('users', ['id' => $id]);
		return $result;
	}

	public function get_records()
	{
		$result = $this->db->get('users')->result();
		return $result;
	}

	public function find_record_by_id( $id)
	{
		$result = $this->db->get_where('users', ['id' => $id])->row();
		return $result;
	}
}
?>
