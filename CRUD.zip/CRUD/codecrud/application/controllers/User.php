<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller {
    public function __construct() {
        parent::__construct();
		$this->load->helper('url');
        $this->load->model('User_model');
    }

    public function index() {
        $data['users'] = $this->User_model->get_records();
		$this->load->view('user/list', $data);
    }

	public function create() {
        $this->load->view('user/create'); // Load the create user view
    }

	public function store()
	{
		$data = array(
			'username' => $this->input->post('username'),
			'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
			'email' => $this->input->post('email')
		);

		$this->User_model->create($data);
		$data['users'] = $this->User_model->get_records();
		$this->session->set_flashdata('message', '<div class="alert alert-success">Record has been saved successfully.</div>');
		$this->load->view('user/list', $data);
    }

    public function edit($id) {
		$data['user'] = $this->User_model->find_record_by_id($id);
	
		if ($this->input->post()) {
			// Handle form submission to edit a user
			$dataToUpdate = array(
				'username' => $this->input->post('username'),
				'email' => $this->input->post('email')
			);
	
			$this->User_model->update($dataToUpdate, $id);
			$this->session->set_flashdata('message', '<div class="alert alert-success">Record has been updated successfully.</div>');
			redirect('user/index'); // Redirect to the user list page after successful update
		} else {
			$this->load->view('user/edit', $data);
		}
	}
	

    public function delete($id) {
        $this->User_model->delete($id);
		$this->session->set_flashdata('message', '<div class="alert alert-success">Record has been deleted successfully.</div>');
		$data['users'] = $this->User_model->get_records();
		$this->load->view('user/list', $data);
    }
}

?>
